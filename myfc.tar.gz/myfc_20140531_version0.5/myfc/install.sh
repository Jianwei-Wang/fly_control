insmod accelerate.ko
mknod /dev/accelerate c 238 0
./test_accelerate
