#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <pthread.h>
#include <fcntl.h>#include<time.h>

#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <ctype.h>
#include <string.h>
#include<pthread.h>
#include "serial_test.h"

#include <linux/fs.h>
#include   <sys/time.h>                  
#include <sys/socket.h>                 
#include <netinet/in.h>                    
#include <arpa/inet.h>                      
#include <netdb.h>                        
int work_continue = 500,work_counter = 1;
int temp_count;
#define longtime 256//长期融合周期
#define gyroaccfactor 60000//加速度和陀螺仪积分匹配常量

int long_counter=0;//计数长期融合
int fd_ahrs,fd_moto,fd_HMC5883;
long gyroData[3],accData[3],HMCData[3];//九轴数据
int angle;
//gyro and accelerate neutral readings
int neutralaccx=1;//加速度中点
int neutralaccy=1;
int neutralaccz=1;
int adneutralnick=1;//陀螺仪中点
int adneutralroll=1;
int adneutralgier=1;
int neutral_HMC = 1;
//gyro readingsHMCData[2]
int reading_gyronick=1;//陀螺仪减常值误差
int reading_gyroroll=1;
int reading_gyroyaw=1;

//mean accelerations
int mean_accroll=1;//加速度减去常值误差
int mean_accnick=1;
int mean_acctop=1;
//attitude gyro integrals
/*
int mess_integralnick=1;
int mess_integralnick2=1;
int mess_integralroll=1;
int mess_integralroll2=1;
int mess_integral_gier=1;
int mess_integral_gier2=1;
*/
int integralyaw=1;//陀螺仪积分  带2的没有修正
int integralnick=1;
int integralroll=1;
int integralnick2=1;
int integralroll2=1;
int reading_integralgyronick=1,reading_integralgyronick2=1;
int reading_integralgyroroll=1,reading_integralgyroroll2=1;
int reading_integralgyroyaw=1;
long meanintegralnick=1;//陀螺仪积分的和
long meanintegralroll=1;
//attitude acceleration integrals
int integralaccnick=1;//加速度的和
int integralaccroll=1;
int reading_integraltop=1;
/*
int mittelintegralnick =1;
int mittelintegralroll =1;
int mittelintegralnick2=1;
int mittelintegralroll2=1; 
*/
int tmp_long=1;//短期融合nick中间变量
int tmp_long2=1;//短期融合roll中间变量
int factornick_short=80;//短期融合 融合比率
int factorroll_short=80;
int factornick_long=70;//长期融合 融合比率
int factorroll_long=70;

int attitudecurrectionroll=1;//长期融合中间变量
int attitudecurrectionnick=1;
int currectionnick=1;
int currectionroll=1;
int meanintegralnick_old=1,meanintegralroll_old=1;//陀螺仪中点微调 上次陀螺仪积分值
int integralerrornick=1,integralerrorroll=1;//陀螺仪中点微调 漂移量
#define gyro_i_factor  2//pi i融合率
#define gyro_p_factor	20//pi p融合率
unsigned char control_buff[10] = {0,0,0,0,0,0,0,0,0,0};
unsigned char check_byte;
int sticknick=0;//摇杆位置
int stickroll=0;
int diffnick=1;
int diffroll=1;
int gasmixfraction=50;
int pd_result=1;
int yawmixfraction=0;
int yaw_control_num = 1;
int motorvalue=1;//临时存放电机值
int motor_front=1,motor_rear=1,motor_left=1,motor_right=1;//四个电机值


struct t

i=1;rrectionclud算时间结构体
struct t

i=1;rend;
struct t

i=1;rwork_recti,work_end;
int timer=1;//lud算 的时间值
int aaa=0;
int tempp;
/////////////////////////////////////串口程序///////////////////
struct serial_config serialread;

static int serial_fd,beep_fd;

int speed_arr[] = {B230400, B115200, B57600, B38400, B19200, B9600, B4800, B2400, B1200, B300,
		   B38400, B19200, B9600, B4800, B2400, B1200, B300};

int name_arr[] = {230400, 115200, 57600, 38400, 19200, 9600, 4800, 2400, 1200, 300,
		  38400, 19200, 9600, 4800, 2400, 1200, 300};

//-----------------------------------------------
//打印配置文件tq2440_serial.cfg的内容
//-----------------------------------------------
void print_serialread()
{
	printf("serialread.dev is %s\n",serialread.serial_dev);
	printf("serialread.speed is %d\n",serialread.serial_speed);
	printf("serialread.databits is %d\n",serialread.databits);
	printf("serialread.stopbits is %d\n",serialread.stopbits);
	printf("serialread.parity is %c\n",serialread.parity);
}

//-----------------------------------------------
//读取tq2440_serial.cfg文件并进行配置
//-----------------------------------------------
void readserialcfg()
{
	FILE *serial_fp;
	char j[10];
	
	printf("readserailcfg\n");
	serial_fp = fopen("/etc/tq2440_serial.cfg","r");
	if(NULL == serial_fp)
	{
		printf("can't open /etc/tq2440_serial.cfg");
	}
	else
	{
		fscanf(serial_fp, "DEV=%s\n", serialread.serial_dev);

		fscanf(serial_fp, "SPEED=%s\n", j);
		serialread.serial_speed = atoi(j);

		fscanf(serial_fp, "DATABITS=%s\n", j);
		serialread.databits = atoi(j);

		fscanf(serial_fp, "STOPBITS=%s\n", j);
		serialread.stopbits = atoi(j);

		fscanf(serial_fp, "PARITY=%s\n", j);
		serialread.parity = j[0];
	}

	fclose(serial_fp);
}

//-----------------------------------------------
//设置波特率
//-----------------------------------------------
void set_speed(int fd_serial)
{
	int i;
	int status;
	struct termios Opt;
	struct termios oldOpt;
	tcgetattr(fd_serial, &oldOpt);
//	printf("serialread.speed is %d\n",serialread.serial_speed);
	for( i = 0; i < sizeof(speed_arr)/sizeof(int); i++)
	{
		if(serialread.serial_speed == name_arr[i])
		{
			tcflush(fd_serial, TCIOFLUSH);
			cfsetispeed(&Opt, speed_arr[i]);
			cfsetospeed(&Opt, speed_arr[i]);
			status = tcsetattr(fd_serial, TCSANOW, &Opt);
			if(status != 0)
			{
				perror("tcsetattr fd1");
				return;
			}
			tcflush(fd_serial, TCIOFLUSH);
		}
	}
}


//-----------------------------------------------
//设置其他参数
//-----------------------------------------------
int set_Parity(int fd_serial)
{
	struct termios options;
	struct termios oldoptions;
	if(tcgetattr(fd_serial, &oldoptions) != 0)
	{
		perror("SetupSerial 1");
		return(FALSE);
	}
	options.c_oflag &= ~OPOST; 
	options.c_cflag |= (CLOCAL|CREAD);
	options.c_cflag &=~CSIZE;
//	printf("serialread.databits is %d\n",serialread.databits);
	switch(serialread.databits)
	{
		case 7:
			options.c_cflag |= CS7;
			break;
		case 8:
			options.c_cflag |= CS8;
			break;
		default:
			options.c_cflag |= CS8;
			fprintf(stderr, "Unsupported data size\n");
			return(FALSE);
	}
//	printf("serialread.parity is %c\n",serialread.parity);
	switch(serialread.parity)
	{
		case 'n':
		case 'N':
			options.c_cflag &= ~PARENB;
			options.c_iflag &= ~INPCK;
			break;
		case 'o':
		case 'O':
			options.c_cflag |= (PARODD | PARENB);
			options.c_iflag |= INPCK;
			break;
		case 'e':
		case 'E':
			options.c_cflag |= PARENB;
			options.c_cflag &= ~PARODD;
			options.c_iflag |= INPCK;
			break;
		default:
			options.c_cflag &= ~PARENB;
			options.c_iflag &= ~INPCK;
			fprintf(stderr, "Unsupported parity\n");
			return(FALSE);
	}
//	printf("serialread.stopbits is %d\n",serialread.stopbits);
	switch(serialread.stopbits)
	{
		case 1:
			options.c_cflag &= ~CSTOPB;
			break;
		case 2:
			options.c_cflag |= CSTOPB;
			break;
		default:
			options.c_cflag &= ~CSTOPB;
			fprintf(stderr, "Unsupported stop bits\n");
			return(FALSE);
	}
	if(serialread.parity != 'n')
		options.c_iflag |= INPCK;
	options.c_cc[VTIME] = 0;	//150;			//15 seconds
	options.c_cc[VMIN] = 0;
	options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);	//选择原始输入
#if 1
	options.c_iflag |= IGNPAR|ICRNL;
	options.c_oflag &= ~OPOST; 
	options.c_iflag &= ~(IXON|IXOFF|IXANY);                     
#endif
	tcflush(fd_serial, TCIFLUSH);
	if(tcsetattr(fd_serial, TCSANOW, &options) != 0)
	{
		perror("SetupSerial 3");
		return(FALSE);
	}
	return(TRUE);
}

//-----------------------------------------------
//打开串口设备
//-----------------------------------------------
int OpenDev(char *Dev)
{
	int fd_serial = open(Dev, O_RDWR, 0);
	if(-1 == fd_serial)
	{
		perror("Can't Open Serial Port");
		return -1;
	}
	else
		return fd_serial;
}

//--------------------------------------------------
//串口初始化
//--------------------------------------------------
void serial_init(void)
{
	char *Dev;

	int i;

	readserialcfg();
	print_serialread();

	Dev = serialread.serial_dev;
	//打开串口设备
	serial_fd = OpenDev(Dev);

	if(serial_fd > 0)
		set_speed(serial_fd);		//设置波特率
	else
	{
		printf("Can't Open Serial Port!\n");
		exit(0);
	}
	//恢复串口未阻塞状态
	if (fcntl(serial_fd, F_SETFL, O_NONBLOCK) < 0)
	{
		printf("fcntl failed!\n");
		exit(0);
	}
	//检查是否是终端设备
#if 1	//如果屏蔽下面这段代码，在串口输入时不会有回显的情况，调用下面这段代码时会出现回显现象。
	if(isatty(STDIN_FILENO)==0)
	{
		printf("standard input is not a terminal device\n");
	}
	else
		printf(" isatty success!\n");
#endif
	//设置串口参数
	if(set_Parity(serial_fd) == FALSE)
	{
		printf("Set parity Error\n");
		exit(1);
	}

}
/*******************************串口程序*****************************/

/*****************************传感器初始化**************************/
int ahrs_init()
{
	fd_ahrs = open("/dev/mpu6050_driver",0);
	if(fd_ahrs<0)
	{
		printf("open /dev/mpu6050_driver error!\n");
		return -1;
	}

	fd_HMC5883=open("/dev/HMC5883_driver",O_RDWR);
	if(fd_HMC5883 < 0)
	{
		printf("open /dev/HMC5883_driver failed \n");
		return (-1);
	}
	printf("fd_HMC5883 = %d\n",fd_HMC5883);

}
/***************************传感器初始化****************************/

/***************************读传感器数据****************************/
void readdata(void)
{
	int ret;
	unsigned char temp[18],temp_HMC[6];
	gettimeofday(&end,NULL);//lud算周期结束
	timer=end.tv_usec-recti.tv_useconclud算时间
	if((timer>8000)||(timer<-8000)) timer=1000;//如果秒值改变，防突变
	gettimeofday(&recti,NULL);//lud算周期开始
	
	ret=read(fd_ahrs,temp,sizeof(temp));
	if(ret<0)
	{
		printf("read err!\n");
	//	continue;
	}    		
	accData[1] = (temp[0] << 8) | temp[1];//把8位数据组合成十六位
    	accData[0] = (temp[2] << 8) | temp[3];
    	accData[2] = (temp[4] << 8) | temp[5];
    	gyroData[0] = (temp[6] << 8) | temp[7];
    	gyroData[1] = (temp[8] << 8) | temp[9];
    	gyroData[2] = (temp[10] << 8) | temp[11];
//    	HMCData[0] = (temp[12] << 8) | temp[13];
//    	HMCData[1] = (temp[14] << 8) | temp[15];
//    	HMCData[2] = (temp[16] << 8) | temp[17];
	if(accData[0]>32768)	accData[0]-=65536;//把补码变回原码
	if((accData[0]>10000)||(accData[0]<-10000))
		accData[0]=mean_accnick+neutralaccx;
	if(accData[1]>32768)	accData[1]-=65536;
	if((accData[0]>10000)||(accData[0]<-10000))
		accData[1]=mean_accroll+neutralaccy;
	if(accData[2]>32768)	accData[2]-=65536;
	if((accData[2]>10000)||(accData[2]<-10000))
		accData[2]=mean_acctop+neutralaccz;
	if(gyroData[0]>32768)	gyroData[0]-=65536;
	if(gyroData[1]>32768)	gyroData[1]-=65536;
	if(gyroData[2]>32768)	gyroData[2]-=65536;

//	if(HMCData[0]>30000)	HMCData[0]-=65536;
//	if(HMCData[1]>30000)	HMCData[1]-=65536;
//	if(HMCData[2]>30000)	HMCData[2]-=65536;

//	printf("%d\n",HMCData[0]);
//	printf("%d\n",HMCData[1]);
//	printf("%d\n",HMCData[2]);

	ret=read(fd_HMC5883,temp_HMC,sizeof(temp_HMC));
	if(ret<0)
	{
		printf("read err!\n");
	} 
    	HMCData[0]=temp_HMC[0] << 8 | temp_HMC[1]; //x
    	HMCData[1]=temp_HMC[2] << 8 | temp_HMC[3]; //z
    	HMCData[2]=temp_HMC[4] << 8 | temp_HMC[5]; //y

	if(HMCData[0]>32768)	HMCData[0]-=65536;//把补码变回原码
	if(HMCData[1]>32768)	HMCData[1]-=65536;
	if(HMCData[2]>32768)	HMCData[2]-=65536;

	angle = atan2((double)HMCData[2],(double)HMCData[0])*180;
	angle = abs(angle);
//	printf("angle = %d \n",angle);
}
/***************************读传感器数据***********************/

/*****************************设置中点*************************/
void setneutral(void)
{
	unsigned char set_neutral=1,a=100;//平均100次

	neutralaccx=0;//中点清零
	neutralaccy=0;
	neutralaccz=0;
	adneutralnick=0;
	adneutralroll=0;
	adneutralgier=0;

	while(set_neutral)//求100次的和
	{
		readdata();
		neutralaccx=neutralaccx+accData[0];
		neutralaccy=neutralaccy+accData[1];
		neutralaccz=neutralaccz+accData[2];
		adneutralnick=adneutralnick+gyroData[0];
		adneutralroll=adneutralroll+gyroData[1];
		adneutralgier=adneutralgier+gyroData[2];
		neutral_HMC += angle;
		if(!(--a)) //求平均值，某些变量清零
		{
			set_neutral=0;
			neutralaccx/=100;
			neutralaccy/=100;
			neutralaccz/=100;

//			neutralaccx=0;
//			neutralaccy=0;
//			neutralaccz=0;
//			adneutralnick=0;
//			adneutralroll=0;
//			adneutralgier=0;
/**********************test**************************/
			adneutralnick/=100;
			adneutralroll/=100;
			adneutralgier/=100;
			neutral_HMC /=100;
	//		adneutralnick=-20;	
	//		adneutralroll=0;

			printf("adneutralnick=%d\n",adneutralnick);
			printf("adneutralroll=%d\n",adneutralroll);
			printf("adneutralgier=%d\n",adneutralgier);

			printf("neutralaccx=%d\n",neutralaccx);
			printf("neutralaccy=%d\n",neutralaccy);
			printf("neutralaccz=%d\n",neutralaccz);

			reading_integralgyronick=0;
			reading_integralgyronick2=0;
			reading_integralgyroroll=0;
			reading_integralgyroroll2=0;
			reading_integralgyroyaw=0;
			reading_gyronick=0;
			reading_gyroroll=0;
			reading_gyroyaw=0;

			integralyaw=0;
			integralnick=0;
			integralroll=0;
			integralnick2=0;
			integralroll2=0;
			meanintegralnick=0;
			meanintegralroll=0;

			mean_accroll=0;
			mean_accnick=0;
			mean_acctop=0;
			mean_acctop=neutralaccz;
//			mess_integralnick=0;
//			mess_integralnick2=0;
//			mess_integralroll=0;
//			mess_integralroll2=0;
//			mess_integral_gier=0;
//			mess_integral_gier2=0;

			integralaccnick=0;
			integralaccroll=0;
			reading_integraltop=0;
			attitudecurrectionroll=0;
			attitudecurrectionnick=0;

		}
	}
}
/****************************设置中点***************************/

/****************************姿态lud算***************************/
void calculate(void)
{

	reading_gyronick=gyroData[0]-adneutralnick;	//陀螺仪减去中值
	reading_gyroroll=adneutralroll-gyroData[1];

	reading_gyroyaw=gyroData[2]-adneutralgier;
//printf("%d\n",reading_gyronick);
//	mean_accnick=(mean_accnick+accData[0]/*-neutralaccx*/)/2;
//	mean_accroll=(mean_accroll+accData[1]/*-neutralaccy*/)/2;
	mean_accnick=accData[0]-neutralaccx;//加速度减去中值
	mean_accroll=accData[1]-neutralaccy;
	mean_acctop=(mean_acctop+accData[2]/*-neutralaccz*/)/2;
//printf("%d\n",mean_accnick);
	integralaccnick+=accData[0]-neutralaccx;//加速度求和  后面长期融合做平均
	integralaccroll+=accData[1]-neutralaccy;
//	reading_integraltop+=accData[2]-neutralaccz;

	reading_integralgyroyaw+=reading_gyroyaw*timer;//陀螺仪积分
//	mess_integral_gier2+=reading_gyroyaw*timer;

	reading_integralgyroroll2+=reading_gyroroll*timer;
	reading_integralgyroroll +=reading_gyroroll*timer-attitudecurrectionroll;//减去长期融合误差

	reading_integralgyronick2+=reading_gyronick*timer;
	reading_integralgyronick +=reading_gyronick*timer-attitudecurrectionnick;

	integralyaw=reading_integralgyroyaw;//
	integralnick=reading_integralgyronick;
	integralroll=reading_integralgyroroll;
	integralnick2=reading_integralgyronick2;
	integralroll2=reading_integralgyroroll2;
}
/*******************************姿态lud算********************************/

/**************************算出姿态l��控制电机**************************/
void motorcontrol(void)
{
	long_counter++;
	readdata();
	calculate();

	meanintegralnick +=integralnick;//陀螺仪积分求和 
	meanintegralroll +=integralroll;
//	mittelintegralnick2+=integralnick2;
//	mittelintegralroll2+=integralroll2; 
//printf("%d\n",meanintegralnick);
	tmp_long= mean_accnick-integralnick/gyroaccfactor;//从加速度看 陀螺仪误差
	tmp_long2=mean_accroll-integralroll/gyroaccfactor;

//	printf("%f\n",mean_accnick);
//	printf("%d     %d\n",integralnick/gyroaccfactor,mean_accnick);
//	printf("integralnick/gyroaccfactor=%d     mean_accnick=%d\n",integralroll/gyroaccfactor,mean_accroll);
//	printf("%d   %d\n\n",tmp_long,tmp_long2);
	#define ausgleich 8000//短期融合值限定
	if(tmp_long>ausgleich)		tmp_long=ausgleich;
	if(tmp_long<-ausgleich)		tmp_long=-ausgleich;
	if(tmp_long2>ausgleich)		tmp_long2=ausgleich;
	if(tmp_long2<-ausgleich)	tmp_long2=-ausgleich;

	reading_integralgyronick += tmp_long*factornick_short;
	reading_integralgyroroll +=tmp_long2*factorroll_short;
//printf("         %d\n",mess_integralnick/gyroaccfactor);
	if(long_counter>=longtime)
	{
		int cnt=0;
		char last_n_p,last_n_n,last_r_p,last_r_n;

//		printf("adneutralnick=%d   adneutralroll=%d\n",adneutralnick,adneutralroll);
//printf("motor_front=%d motor_rear=%d\n",motor_front,motor_rear);

		long_counter=0;

		meanintegralnick=meanintegralnick/gyroaccfactor/longtime;//陀螺仪积分求平均
		meanintegralroll=meanintegralroll/gyroaccfactor/longtime;
		integralaccnick/=longtime;//加速度求平均
		integralaccroll/=longtime;
//printf("%d\n",accData[0]);
//printf("integralaccnick=%d\n",integralaccnick);
//printf("integralaccroll=%d\n",integralaccroll);
		currectionnick=meanintegralnick-integralaccnick;
		attitudecurrectionnick=currectionnick/factornick_long;

//printf("%d\n",attitudecurrectionnick);
		currectionroll=meanintegralroll-integralaccroll;
		attitudecurrectionnick=currectionroll/factorroll_long;

//printf("%d   %d    %d\n",attitudecurrectionnick,integralaccnick,meanintegralnick);
		#define ausgleich_long 400
		if(attitudecurrectionnick>ausgleich_long)attitudecurrectionnick=ausgleich_long;
		if(attitudecurrectionnick<-ausgleich_long)attitudecurrectionnick=-ausgleich_long;

//后面为中点微调
		integralerrornick=integralnick2-integralnick;
		reading_integralgyronick2-=integralerrornick;
		integralerrorroll=integralroll2-integralroll;
		reading_integralgyroroll2-=integralerrorroll;
//printf("%d  %d\n",meanintegralnick_old,meanintegralnick);

		#define error_limit  2000000
		#define error_limit2 500000*4
		#define movement_limit 40
		cnt=0;
		currectionnick=0;
		if(abs(meanintegralnick_old-meanintegralnick)<movement_limit)
		{
			if(integralerrornick>error_limit2)
			{
				if(last_n_p)
				{
					cnt+=abs(integralerrornick)/error_limit2;
					currectionnick=integralerrornick/gyroaccfactor;
					if(currectionnick>5)	currectionnick=5;
					if(currectionnick<-5)	currectionnick=-5;

//					printf("%d\n",currectionnick);
//					attitudecurrectionnick-=currectionnick;
				}
				else last_n_p=1;
			}
			else last_n_p=0;
			if(integralerrornick<-error_limit2)
			{
				if(last_n_n)
				{
					cnt+=abs(integralerrornick)/error_limit2;
					currectionnick=integralerrornick/gyroaccfactor;
					if(currectionnick>5)	currectionnick=5;
					if(currectionnick<-5)	currectionnick=-5;
//					printf("%d\n",currectionnick);
//					attitudecurrectionnick-=currectionnick;
				}
				else last_n_n=1;
			}
			else last_n_n=0;
		}
		else cnt=0;
		if(cnt>2) cnt=2;
		if(integralerrornick>error_limit) adneutralnick+=0;//cnt;
		if(integralerrornick<-error_limit)adneutralnick-=0;//cnt;
		meanintegralnick_old=meanintegralnick;
		integralaccnick=0;
		integralaccroll=0;
		meanintegralnick=0;
		meanintegralroll=0;

//		yawmixfraction = -(neutral_HMC - angle)/10;
//		yaw_control_num = 3;
	}
//printf("integralnick*gyro_i_factor=%d  reading_gyronick*gyro_p_factor=%d\n",integralnick*gyro_i_factor/10000000,reading_gyronick*gyro_p_factor/1000);
       reading_gyronick=integralnick*gyro_i_factor/10000000+reading_gyronick*gyro_p_factor/1500;
       reading_gyroroll=integralroll*gyro_i_factor/10000000+reading_gyroroll*gyro_p_factor/1500;

	#define max_yawmixfraction 8
	if(yawmixfraction> max_yawmixfraction) yawmixfraction = max_yawmixfraction;
	if(yawmixfraction<-max_yawmixfraction) yawmixfraction =-max_yawmixfraction;

	#define max_sensor 20
	if(reading_gyronick> max_sensor) reading_gyronick= max_sensor;
	if(reading_gyronick<-max_sensor) reading_gyronick=-max_sensor;
	if(reading_gyroroll> max_sensor) reading_gyroroll= max_sensor;
	if(reading_gyroroll<-max_sensor) reading_gyroroll=-max_sensor;

	//nick-axis
	diffnick=reading_gyronick-sticknick;
	pd_result=diffnick;
	
	#define tmp_int 30
	if(pd_result> tmp_int) pd_result= tmp_int;
	if(pd_result<-tmp_int) pd_result=-tmp_int;

	// motor front
	motorvalue=gasmixfraction+pd_result+yawmixfraction;

	if(motorvalue<5)	motorvalue=5;
	if(motorvalue>80)	motorvalue=80;
	motor_front=motorvalue;
	// motor rear
	motorvalue=gasmixfraction-pd_result+yawmixfraction;

	if(motorvalue<5)	motorvalue=5;
	if(motorvalue>80)	motorvalue=80;
	motor_rear=motorvalue;

	//roll-axis
	diffroll=reading_gyroroll-stickroll;
	pd_result=diffroll;
	
	if(pd_result> tmp_int) pd_result= tmp_int;
	if(pd_result<-tmp_int) pd_result=-tmp_int;

	// motor left
	motorvalue=gasmixfraction+pd_result-yawmixfraction;

	if(motorvalue<5)	motorvalue=5;
	if(motorvalue>80)	motorvalue=80;
	motor_left=motorvalue;
	// motor right
	motorvalue=gasmixfraction-pd_result-yawmixfraction;

	if(motorvalue<5)	motorvalue=5;
	if(motorvalue>80)	motorvalue=80;
	motor_right=motorvalue;

//	if(!(yaw_control_num--))
		yawmixfraction = 0;

}
/*****************************算出姿态l��控制电机********************/

/************************************************************/
void stick_control()
{
	if((0x0b==control_buff[0])&&(0x09==control_buff[1]))
	{
		if(control_buff[9]^check_byte)
		{
			printf("control_buff[2] = %d ; gasmixfraction = %d \n",control_buff[2],gasmixfraction);
			if(control_buff[2]<(gasmixfraction+10))
			{
				gasmixfraction = control_buff[2];
			}
			else
				gasmixfraction += 10;

			if((control_buff[3]>90) && (control_buff[3]<110))
				sticknick = control_buff[3] - 100;
			else
			{
				if(control_buff[3]>=110)
					sticknick = 10;
				else
					sticknick = -10;
			}

			if((control_buff[4]>90) && (control_buff[4]<110))
				stickroll = control_buff[4] - 100;
			else
			{
				if(control_buff[4]>=110)
					stickroll = 10;
				else
					stickroll = -10;
			}
		check_byte = control_buff[9];
		printf("gasmixfraction = %d ; sticknick = %d ; stickroll = %d \n",gasmixfraction,sticknick,stickroll);
		printf("motor_rear = %d \n",motor_rear);
		printf("motor_front = %d \n",motor_front);
		printf("motor_left = %d \n",motor_left);
		printf("motor_right = %d \n",motor_right);
		}

	}

}
/************************************************************/




/******************************向上位机发送数据*********************/
int serial_scan(void)
{

	int nread,nwrite;
	char buff2[24];
	char ctemp;
	float gx,gy,gx2,gy2;
	int presec;

	serial_init();
	while(1)
	{

		aaa=0xaf+2;
		buff2[0]=0xa5;buff2[1]=0x5a;buff2[2]=16;buff2[3]=0xa1;
		gx=reading_integralgyronick/gyroaccfactor*0.1125;
		gy=reading_integralgyroroll/gyroaccfactor*0.1125;

			printf("x = %f  y = %f\n",gx,gy);
			
		buff2[4]=0;buff2[5]=0;
		if((int)gx<0) gx=32768-(int)gx;
		ctemp=(int)gx>>8;
		buff2[6]=ctemp;
		aaa+=ctemp;
		ctemp=(int)gx;
		buff2[7]=ctemp;
		aaa+=ctemp;

		if((int)gy<0) gy=32768-(int)gy;
		ctemp=(int)gy>>8;
		buff2[8]=ctemp;
		aaa+=ctemp;
		ctemp=(int)gy;
		buff2[9]=ctemp;
		aaa+=ctemp;

		buff2[10]=0;buff2[11]=0;
		buff2[12]=0;buff2[13]=0;
		buff2[14]=0;buff2[15]=0;

		buff2[16]=aaa;buff2[17]=0xaa;
		nwrite = write(serial_fd,buff2,18);

		usleep(50000);
//	      nread=read(serial_fd,control_buff,10);
		stick_control();
//   	   	printf("nread=%d,%s\n",nread,control_buff);
	}
}
/**************************向上位机发送数据**************************/

int net_control()
{
	int sockfd;
	struct sockaddr_in  servaddr;
	char buf[128];
//	if(argc != 3)
//	{
//		printf("Usage: ./client server_ip port\n");
//		exit(-1);
//	}

	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("socket");
		exit(1);
	}

	printf("socket = %d\n", sockfd);

	memset(&servaddr, 0, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(2000);
	servaddr.sin_addr.s_addr = inet_addr("192.168.1.19");

	if(connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
	{
		perror("connect");
		exit(0);
	}

	while(1)
	{
		memset(buf, 0, sizeof(buf));
		if(recv(sockfd, buf, sizeof(buf), 0) <= 0)
		{
			printf("There is no service anymore!\n");
		}
		printf("buf = %s\n", buf);
		if(buf[0] == '1' && buf[1] == '1' && buf[8] == '0' && buf[9] == '9')
		{
			switch(buf[2])
			{
				case 'F':	
					sticknick = 10;
					temp_count = 0;
					printf("F\n"); break;
				case 'f':	
					sticknick = 5;
					temp_count = 0;
					printf("F\n"); break;
				case 'B':	
					sticknick = -10;
					temp_count = 0;
					printf("B\n"); break;
				case 'b':	
					sticknick = -5;
					temp_count = 0;
					printf("B\n"); break;
				case 'L':	
					stickroll = -10;
					temp_count = 0;
					printf("L\n"); break;
				case 'l':	
					stickroll = -5;
					temp_count = 0;
					printf("L\n"); break;
				case 'R':
					stickroll = 10;
					temp_count = 0;	
					printf("R\n"); break;
				case 'r':
					stickroll = 5;
					temp_count = 0;	
					printf("R\n"); break;
				case 'U':	
					gasmixfraction++;
					printf("U\n"); break;
				case 'u':	
					gasmixfraction++;
					printf("U\n"); break;
				case 'D':	
					gasmixfraction--;
					printf("D\n"); break;
				case 'd':	
					gasmixfraction--;
					printf("D\n"); break;
				case '2':
					sticknick++;
					stickroll--;	
					printf("2\n"); break;
				case '1':	
					sticknick++;
					stickroll++;
					printf("1\n"); break;
				case '3':	
					sticknick--;
					stickroll--;
					printf("3\n"); break;
				case '4':	
					sticknick--;
					stickroll++;
					printf("4\n"); break;
				case 'S':	
					sticknick = 0;
					stickroll = 0;
					gasmixfraction -=10;
					printf("S\n"); break;
			}
		work_continue = 500;
		
		}
		else continue;
	usleep(100000);	
	}
	
	close(sockfd);
	return 0;
}


int main(void)
{
	char sign=0;
    	int i,k=20;
	pthread_t th_serial,th_net;
	unsigned char moto1[8];

	fd_moto=open("/dev/moto_driver",O_RDWR);

	if(fd_moto < 0)
	{
		printf("open /dev/moto_driver failed \n");
		return (-1);
	}
	printf("fd_moto=%d\n",fd_moto);

	ahrs_init();
	setneutral();
	usleep(5000000);
	pthread_create(&th_serial,NULL,serial_scan,0);
//	pthread_create(&th_net,NULL,net_control,0);
	for(i=0 ; i<200 ; i++)
	{
		moto1[0]=0x52;moto1[1]=30;
		moto1[2]=0x54;moto1[3]=30;
		moto1[4]=0x56;moto1[5]=30;
		moto1[6]=0x58;moto1[7]=30;
		write(fd_moto,&moto1,8);
		usleep(10000);
	}
	for(;;)
	{
		if(work_continue != 0)
			work_continue--;
		else
		{
			work_continue = 500;    //work_continue = 0;
			work_counter++;
			if(work_counter >= 20)
			{
				work_counter = 0;
//				gasmixfraction--;
			}
		}
	

		motorcontrol();
	
	moto1[0]=0x52;moto1[1]=motor_left;
	moto1[2]=0x54;moto1[3]=motor_front;
	moto1[4]=0x56;moto1[5]=motor_rear;
	moto1[6]=0x58;moto1[7]=motor_right;

	if(500 == temp_count)
	{

		printf("sticknick = %d   stickroll = %d\n",sticknick,stickroll);


		sticknick = 0;
		stickroll = 0;

		printf("motor_rear = %d \n",motor_rear);
		printf("motor_front = %d \n",motor_front);
		printf("motor_left = %d \n",motor_left);
		printf("motor_right = %d \n",motor_right);
//		printf("HMC_x = %d   HMC_z = %d    HMC_y = %d\n",HMCData[0],HMCData[1],HMCData[2]);
//		angle = atan2((double)HMCData[2],(double)HMCData[0])*180;
//		angle = abs(angle);
//		printf("angle = %d \n",angle);
//		gasmixfraction++;
	}
	if(temp_count < 1000)
		temp_count++;

	if(sign)
	{
		write(fd_moto,&moto1,8);
		sign=0;
	}
	else
		sign=1;	              
	}
	close(serial_fd);
}
