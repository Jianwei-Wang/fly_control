chmod 777 myfc
rmmod mpu6050_driver.ko
rmmod moto_driver.ko
rmmod HMC5883_driver.ko
insmod mpu6050_driver.ko
insmod moto_driver.ko
insmod HMC5883_driver.ko
mknod /dev/mpu6050_driver c 238 0
mknod /dev/moto_driver c 25 0
mknod /dev/HMC5883_driver c 239 0
./myfc
